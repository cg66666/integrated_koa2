/*
 * @Description: file content
 * @Author: cg
 * @Date: 2024-09-08 03:29:46
 * @LastEditors: cg
 * @LastEditTime: 2024-10-30 15:58:42
 */
// stores/user.js
import { defineStore } from 'pinia'
import { ref } from 'vue'
import { getPermission } from '@/services/permission'
import type { permissionType } from '@/interface/user'
import type { MagicString } from 'vue/compiler-sfc'

const handlePermission = (data: permissionType) => {}

export type handlePermission = Record<
  string,
  {
    route: string[]
  }
>

export const useUserStore = defineStore('user', () => {
  // 按钮权限
  const permissions = ref<handlePermission>({})

  // 路由权限
  const routePermissions = ref<string[]>([])

  const updatePermissions =  () => {
  
  }

  return { permissions, updatePermissions, routePermissions }
})
