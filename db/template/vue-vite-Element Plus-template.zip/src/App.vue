<!--
 * @Description: file content
 * @Author: cg
 * @Date: 2024-09-03 11:13:17
 * @LastEditors: cg
 * @LastEditTime: 2024-10-30 15:57:28
-->
<script setup lang="ts">
import { onBeforeMount, onMounted, watch } from 'vue'
import { RouterLink, RouterView } from 'vue-router'

onBeforeMount(async () => {
})
</script>

<template>
  <div class="app">
    <RouterView> </RouterView>
  </div>
</template>

<style lang="scss" scoped>
.app {
  width: 100vw;
  height: 100vh;
  overflow: hidden;
}
</style>
