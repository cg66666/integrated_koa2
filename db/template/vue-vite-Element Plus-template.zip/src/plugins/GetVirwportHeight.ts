/*
 * @Description: file content
 * @Author: cg
 * @Date: 2024-09-09 09:20:31
 * @LastEditors: cg
 * @LastEditTime: 2024-09-09 10:47:22
 */
import type { App } from 'vue'
// 全局注入视口高度
export default (app: App) => {
  const clientHeight =
    window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
  app.provide('viewportHeight', clientHeight)
}
