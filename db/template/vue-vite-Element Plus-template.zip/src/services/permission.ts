/*
 * @Description: file content
 * @Author: cg
 * @Date: 2024-09-04 10:15:05
 * @LastEditors: cg
 * @LastEditTime: 2024-09-09 15:53:57
 */
import { get, post } from '@/utils/ajax'
import type { permissionType } from '@/interface/user'

export const getPermission = async () => {
  return await get<permissionType[]>('/cosmo-demo/api/v1/permission')
}
