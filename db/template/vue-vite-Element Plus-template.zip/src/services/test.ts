/*
 * @Description: file content
 * @Author: cg
 * @Date: 2024-09-04 10:15:05
 * @LastEditors: cg
 * @LastEditTime: 2024-09-09 15:40:43
 */
import { get, post } from '@/utils/ajax'

interface userInfo {
  name: string
  sex: number
}

export const getInfo = async (id: number) => {
  return await get<userInfo>('/cosmo-demo/api/v1/demo', { id })
}

export const getInfo2 = async () => {
  return await post<userInfo>('/cosmo-demo/api/v1/demo')
}
