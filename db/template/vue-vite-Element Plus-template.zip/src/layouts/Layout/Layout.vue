<!--
 * @Description: file content
 * @Author: cg
 * @Date: 2024-09-04 13:51:01
 * @LastEditors: cg
 * @LastEditTime: 2024-10-30 16:18:20
-->
<template>
  <div class="outLine">
    <el-menu
      :default-active="activeIndex"
      class="el-menu-demo"
      mode="horizontal"
      @select="handleSelect"
    >
      <el-menu-item index="1">Processing Center</el-menu-item>
      <el-menu-item index="2">Processing Center</el-menu-item>
      <el-menu-item index="3">Processing Center</el-menu-item>
      <el-menu-item index="4">Processing Center</el-menu-item>
    </el-menu>
    <el-button v-permission="'logout'" class="loginOut">退出登录</el-button>
    <div class="content">
      <RouterView />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, h, watch, onBeforeMount } from 'vue'
import { RouterLink, RouterView, useRouter, type RouteRecord } from 'vue-router'
import { useUserStore } from '@/stores/index'

const userStore = useUserStore()
const router = useRouter()
const renderMenu = ref<any[]>([])

// watch(
//   () => userStore.routePermissions,
//   (nv) => {
//     if (nv.length) {
//       renderMenu.value = router
//         .getRoutes()
//         .filter((item) => item.meta.isMenu && nv.includes('/demo' + item.path))
//         .map((item) => ({ key: item.name, label: item.meta.title, ...item.meta }))
//       if (renderMenu.value.length && router.currentRoute.value.name) {
//         activeIndex.value = [String(router.currentRoute.value.name)]
//       }
//     }
//   },
//   { immediate: true }
// )

const activeIndex = ref('1')
const handleSelect = (key: string, keyPath: string[]) => {
  console.log(key, keyPath)
}
</script>

<style lang="scss" scoped>
.outLine {
  width: 100%;
  height: 100%;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  position: relative;
  .loginOut {
    position: absolute;
    right: 30px;
    top: 7px;
  }
  .content {
    flex: 1;
  }
  :deep(.ant-menu) {
    display: flex;
    justify-content: center;
  }
}
</style>
