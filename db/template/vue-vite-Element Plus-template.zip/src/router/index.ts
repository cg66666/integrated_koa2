/*
 * @Description: file content
 * @Author: cg
 * @Date: 2024-09-03 11:13:17
 * @LastEditors: cg
 * @LastEditTime: 2024-09-10 14:01:23
 */
import { createRouter, createWebHistory } from 'vue-router'
import Layout from '@/layouts/Layout/Layout.vue'
import { useUserStore } from '@/stores/index'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      component: Layout,
      children: [
        {
          path: '/',
          redirect: '/home'
        },
        {
          path: '/home',
          name: 'Home',
          component: () => import('@/pages/Home.vue'),
          meta: {
            title: '首页',
            // icon: 'role',
            isMenu: true
          }
        },
        {
          path: '/about',
          name: 'About',
          component: () => import('@/pages/About.vue'),
          meta: {
            title: '关于',
            // icon: 'role',
            isMenu: true
          }
        }
      ]
    },
    // 其他路由...
    { path: '/:pathMatch(.*)*', component: () => import('@/pages/NotFound.vue') } // 404 路由
  ]
})

// 路由全局守卫
router.beforeEach(async (to, from, next) => {
  const userStore = useUserStore()
  if (!Object.keys(userStore.permissions).length) await userStore.updatePermissions()
  console.log('to',to);
  
  // if (to.fullPath === '/404' || userStore.routePermissions.includes('/demo' + to.fullPath)) {
    next()
  // } else {
    // next('/404')
  // }
})

export default router
