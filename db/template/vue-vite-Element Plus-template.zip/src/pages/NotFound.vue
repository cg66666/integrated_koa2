<!--
 * @Description: file content
 * @Author: cg
 * @Date: 2024-09-09 17:03:37
 * @LastEditors: cg
 * @LastEditTime: 2024-09-09 17:51:28
-->
<template>
  <div class="not-found">
    <h1>404 - Page Not Found</h1>
    <p>The page you are looking for does not exist.</p>
    <router-link to="/">Go back to home</router-link>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped>
.not-found {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  text-align: center;
}

.not-found h1 {
  font-size: 3rem;
  color: #333;
}

.not-found p {
  font-size: 1.5rem;
  color: #666;
  margin-bottom: 20px;
}

.not-found a {
  background-color: #007bff;
  color: white;
  padding: 10px 20px;
  border-radius: 5px;
  text-decoration: none;
  transition: background-color 0.3s ease;
}

.not-found a:hover {
  background-color: #0056b3;
}
</style>
