<!--
 * @Description: file content
 * @Author: cg
 * @Date: 2024-09-03 11:13:17
 * @LastEditors: cg
 * @LastEditTime: 2024-09-09 17:46:29
-->
<script setup lang="ts"></script>

<template>
  <div>首页</div>
  <div v-permission="'blue'">权限：蓝</div>
  <div v-permission="'red'">权限：红</div>
  <iframe
    v-permission="'showIframe'"
    src="https://www.cosmosource.com/#:~:text=%E8%AE%A9%E6%95%B0%E5%AD%97%E5%8C%96%E6%88%90%E4%B8%BA%E7%94%9F%E4%BA%A7"
    width="100%"
    height="100%"
  ></iframe>
</template>
