// 权限
export interface permissionType {
  resourceId: number // 权限id
  name: string // 名称
  type: 'menu' | 'route' | 'button' // 权限类型（menu.菜单；route.路由；button.按钮）
  route?: string // 路由（菜单地址|按钮定义变量）
  resourceCode: string // 编码
  children?: permissionType[] // 下级权限信息
}
