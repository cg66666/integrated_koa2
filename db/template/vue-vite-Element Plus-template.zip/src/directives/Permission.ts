/*
 * @Description: file content
 * @Author: cg
 * @Date: 2024-09-09 11:39:01
 * @LastEditors: cg
 * @LastEditTime: 2024-09-09 18:15:07
 */
import type { App, DirectiveBinding } from 'vue'
import { useUserStore } from '@/stores/index'

export const Permission = (app: App) => {
  return app.directive('permission', async (el: any, binding: DirectiveBinding, vnode) => {
    el.style.opacity = 0
    const userStore = useUserStore()
    const { value } = binding
    if (!Object.keys(userStore.permissions).length) await userStore.updatePermissions()
    if (
      userStore.permissions[value] &&
      userStore.permissions[value].route &&
      (userStore.permissions[value].route.includes(window.location.pathname) ||
        userStore.permissions[value].route.includes('*'))
    ) {
      el.style.opacity = 1
    } else {
      el.parentNode && el.parentNode.removeChild(el)
    }
  })
}
