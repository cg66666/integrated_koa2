<!--
 * @Description: file content
 * @Author: cg
 * @Date: 2024-09-04 15:06:11
 * @LastEditors: cg
 * @LastEditTime: 2024-09-09 16:50:04
-->
<template>
  <div class="demo">全局组件{{ props.name }}</div>
</template>

<script setup lang="ts">
const props = defineProps<{ name?: string; color?: string; size?: string }>()
</script>

<style lang="scss" scoped>
.demo {
  background: red;
  border-radius: 3px;
  padding: 5px;
  width: 250px;
  text-align: center;
}
</style>
