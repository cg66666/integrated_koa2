# 项目名称

## 简介

## 技术构架

基础框架 vue3 + typescript + vite
ui 组件库 [Ant Design](https://www.antdv.com/docs/vue/introduce-cn/)

## 开发环境搭建

### 环境要求

node > 18

### 安装运行前端依赖

```sh
pnpm i
npm run dev
```

### 前端打包

```sh
npm run build
```

## 项目结构

```sh
项目根目录
├── .husky/                 #脚本相关配置
├── src/
│   ├── assets/             #静态文件
│   ├── global.scss         #全局样式
│   ├── assets/             #静态文件
│   ├── interfaces/         #公共typescript定义
│   ├── layouts/            #框架结构
│   ├── pages/              #路由文件
│   ├── components/         #全局组件
│   ├── services/           #接口请求
│   ├── utils/              #公共方法
│   ├── directives/         #自定义指令
│   ├── plugins/            #插件
│   ├── router/             #路由
│   ├── stores/             #pinia
│   ├── normalize.css       #初始化样式
│   └── ...
├── package.json
├── vite.config.ts
├── README.md
└── ...
```
