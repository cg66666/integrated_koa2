/*
 * @Description: 开发环境的配置代理工具
 * @Author: cg
 * @Date: 2024-09-04 10:33:13
 * @LastEditors: cg
 * @LastEditTime: 2024-09-11 14:31:09
 */

const url = 'http://192.168.1.233:5080'

export default {
  '/cag': {
    target: url // 真实接口地址, 后端给的基地址
  },
  '/oauth2': {
    target: url // 真实接口地址, 后端给的基地址
  },
  '/login': {
    target: url // 真实接口地址, 后端给的基地址
  },
  '/cac': {
    target: url // 真实接口地址, 后端给的基地址
  },
  '/cosmo-demo': {
    target: 'http://192.168.8.31:8080',
    changeOrigin: true // 允许跨域
    // rewrite: (path) => path.replace(/^\/cosmo-demo/, '')
  }
}
