/*
 * @Description: file content
 * @Author: cg
 * @Date: 2024-10-23 17:05:26
 * @LastEditors: cg
 * @LastEditTime: 2024-10-23 17:05:45
 */
// components/Home.js

const Home: React.FC = () => (
  <div>
    <h2>Home</h2>
    <p>Welcome to the home page.</p>
  </div>
)

export default Home
