/*
 * @Description: file content
 * @Author: cg
 * @Date: 2024-10-23 17:21:01
 * @LastEditors: cg
 * @LastEditTime: 2024-10-30 15:50:01
 */
// Layout.js
import React from 'react'
import { Link, Outlet } from 'react-router-dom'
import { ConfigProvider, Image, Modal, message, Spin } from 'antd'
import zh_CN from 'antd/es/locale/zh_CN'

const Layout = () => {
  return (
    <div>
      <div>头部</div>
      <nav>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/about">About</Link>
          </li>
        </ul>
      </nav>
      <ConfigProvider
        locale={zh_CN}
        // input={{ autoComplete: "off" }}
        // renderEmpty={customizeRenderEmpty}
      >
        <Outlet></Outlet>
      </ConfigProvider>
    </div>
  )
}

export default Layout
