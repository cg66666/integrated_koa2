/*
 * @Description: file content
 * @Author: cg
 * @Date: 2024-09-03 11:13:17
 * @LastEditors: cg
 * @LastEditTime: 2024-09-09 18:06:52
 */
import { fileURLToPath, URL } from 'node:url'

import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import { ElementPlusResolver, AntDesignVueResolver } from 'unplugin-vue-components/resolvers'

import proxy from './proxy'

// https://vitejs.dev/config/
export default defineConfig({
  base: '/demo/',
  plugins: [
    vue(),
    Components({
      // 指定组件按需引入所在文件夹的位置，默认是src/components
      dirs: ['src/components'],
      // 配置type文件生成位置，默认是components.d.ts
      dts: 'components.d.ts',
      // 禁止importStyle，因为新版antdesign使用CSS-in-JS
      resolvers: [AntDesignVueResolver({ importStyle: false })]
    })
  ],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    }
  },
  css: {
    preprocessorOptions: {
      scss: {
        api: 'modern-compiler'
      }
    }
  },
  server: {
    port: 8000,
    proxy
  }
})
