/*
 * @Description: file content
 * @Author: cg
 * @Date: 2024-09-03 11:13:17
 * @LastEditors: cg
 * @LastEditTime: 2024-09-10 14:15:56
 */
// import './assets/main.css'

import { createApp } from 'vue'
import { createPinia } from 'pinia'

import Antd, { install } from 'ant-design-vue'

import App from './App.vue'
import router from './router'

// import Lazyload from '@/directives/Lazyload'

// import Persmission from '@/directives/Permission'

import { Lazyload, Permission } from '@/directives/index'

import GetVirwportHeight from '@/plugins/GetVirwportHeight'

import { useUserStore } from '@/stores/index'

import './normalize.css'
import 'ant-design-vue/dist/reset.css'
import './global.scss'

const app = createApp(App)

app.use(createPinia())

app.use(router)

// 自定义插件、自定义指令定义
app.use({
  install(app) {
    Permission(app)
    Lazyload(app)
    GetVirwportHeight(app)
  }
})

// app.use(Antd)

app.mount('#app')
