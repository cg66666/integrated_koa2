<!--
 * @Description: file content
 * @Author: cg
 * @Date: 2024-09-03 11:13:17
 * @LastEditors: cg
 * @LastEditTime: 2024-09-09 16:50:31
-->
<template>
  <div>关于内容</div>
  <DemoComponent />
  <DemoComponent333 v-permission="'red'" name=" 权限：红" />
  <a-button v-permission="'green'">权限：绿</a-button>
</template>

<style></style>
