<!--
 * @Description: file content
 * @Author: cg
 * @Date: 2024-09-04 13:51:01
 * @LastEditors: cg
 * @LastEditTime: 2024-10-30 16:00:33
-->
<template>
  <div class="outLine">
    <a-menu v-model:selectedKeys="current" mode="horizontal" :items="items" />
    <a-button v-permission="'logout'" class="loginOut">退出登录</a-button>
    <div class="content">
      <RouterView />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, h, watch, onBeforeMount } from 'vue'
import { RouterLink, RouterView, useRouter, type RouteRecord } from 'vue-router'
import { useUserStore } from '@/stores/index'
import { MailOutlined, AppstoreOutlined, SettingOutlined } from '@ant-design/icons-vue'
import { MenuProps } from 'ant-design-vue'

const userStore = useUserStore()
const router = useRouter()
const renderMenu = ref<any[]>([])
const activeIndex = ref(['Home'])
const handleSelect = (item: any) => router.push({ name: item.key })

// watch(
//   () => userStore.routePermissions,
//   (nv) => {
//     if (nv.length) {
//       renderMenu.value = router
//         .getRoutes()
//         .filter((item) => item.meta.isMenu && nv.includes('/demo' + item.path))
//         .map((item) => ({ key: item.name, label: item.meta.title, ...item.meta }))
//       if (renderMenu.value.length && router.currentRoute.value.name) {
//         activeIndex.value = [String(router.currentRoute.value.name)]
//       }
//     }
//   },
//   { immediate: true }
// )

const current = ref<string[]>(['mail'])

const items = ref<MenuProps['items']>([
  {
    key: 'mail',
    icon: () => h(MailOutlined),
    label: 'Navigation One',
    title: 'Navigation One'
  },
  {
    key: 'app',
    icon: () => h(AppstoreOutlined),
    label: 'Navigation Two',
    title: 'Navigation Two'
  },
  {
    key: 'sub1',
    icon: () => h(SettingOutlined),
    label: 'Navigation Three - Submenu',
    title: 'Navigation Three - Submenu',
    children: [
      {
        type: 'group',
        label: 'Item 1',
        children: [
          {
            label: 'Option 1',
            key: 'setting:1'
          },
          {
            label: 'Option 2',
            key: 'setting:2'
          }
        ]
      },
      {
        type: 'group',
        label: 'Item 2',
        children: [
          {
            label: 'Option 3',
            key: 'setting:3'
          },
          {
            label: 'Option 4',
            key: 'setting:4'
          }
        ]
      }
    ]
  }
])
</script>

<style lang="scss" scoped>
.outLine {
  width: 100%;
  height: 100%;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  position: relative;
  .loginOut {
    position: absolute;
    right: 30px;
    top: 7px;
  }
  .content {
    flex: 1;
  }
  :deep(.ant-menu) {
    display: flex;
    justify-content: center;
  }
}
</style>
