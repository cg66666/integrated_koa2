import "umi/typings";

/**
 * 项目配置信息
 */
export interface IProjectConfig {
  inIframe: boolean;
  /**
   * 产品简称
   */
  projectName: string;
  /**
   * 产品名称
   */
  projectTitle: string;
  /**
   * 浏览器图标
   */
  icon: string;
  /**
   * 导航栏图标
   */
  logo: React.ReactNode;
  /**
   * 关于窗图标
   */
  logo128: React.ReactNode;
  /**
   * cac 使用的url
   */
  cacUrl: string;
}

declare global {
  interface Window {
    g: IProjectConfig;
  }
}
