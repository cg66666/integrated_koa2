/*
 * @Description: file content
 * @Author: cg
 * @Date: 2024-09-20 15:20:51
 * @LastEditors: cg
 * @LastEditTime: 2024-09-29 11:13:07
 */
export default [
  {
    path: "/404",
    component: "./404",
  },
  {
    path: "/",
    component: "@/layouts/Layout",
    routes: [
      {
        path: "/",
        redirect: "/Test",
      },
      {
        path: "/Test",
        component: "@/pages/Test",
        name: "Test",
        label: "测试页",
      },
    ],
  },
  {
    path: "*",
    component: "./404",
  },
];
