/*
 * @Description: file content
 * @Author: cg
 * @Date: 2024-08-27 17:39:11
 * @LastEditors: cg
 * @LastEditTime: 2024-10-23 16:44:58
 */
import { defineConfig } from "umi";
import routes from "./routes";
import proxy from "./proxy";

export default defineConfig({
  base: "/demo/",
  // 配置项目路径
  publicPath: "/demo/",
  routes,
  proxy,
  // 添加插件
  // plugins: ["@umijs/plugins/dist/dva"],
  // dva: {
  //   // hmr: true,
  //   // immer: { enableES5: true }
  // },
  npmClient: "pnpm",
});
