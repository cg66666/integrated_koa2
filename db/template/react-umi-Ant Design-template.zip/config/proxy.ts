/*
 * @Description: file content
 * @Author: cg
 * @Date: 2024-08-27 17:54:39
 * @LastEditors: cg
 * @LastEditTime: 2024-09-26 11:23:58
 */

/**
 * 在生产环境 代理是无法生效的，所以这里没有生产环境的配置
 * The agent cannot take effect in the production environment
 * so there is no configuration of the production environment
 * For details, please see
 * https://pro.ant.design/docs/deploy
 */
const url = "http://192.168.1.232:5080";

export default {
  "/cag/": {
    target: url,
  },
  "/oauth2/": {
    target: url,
  },
  "/login/": {
    target: url,
  },
  "/cac/": {
    target: url,
  },
  "/portal-site/": {
    target: "http://192.168.1.232:19987",
    changeOrigin: true,
    logLevel: "debug",
    // pathRewrite: { "^/portal-site": "" },
  },
} as any;
