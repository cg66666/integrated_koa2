/**
 * http返回基类
 */
export interface IBaseResponse<T> {
  code: string;
  data: T;
  error: string;
  successful: boolean;
  message: string;
}

/**
 * 分页返回
 */
export interface IPageList<T> {
  list: T;
  page: number;
  total: number;
}

/**
 * http返回基类
 */
export interface IBaseResponseWithPage<T> {
  code: string;
  data: IPageList<T>;
  error: string;
  info: string;
  successful: boolean;
}
