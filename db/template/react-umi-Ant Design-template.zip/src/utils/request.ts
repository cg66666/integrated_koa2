/*
 * @Description: file content
 * @Author: cg
 * @Date: 2024-05-20 16:11:33
 * @LastEditors: cg
 * @LastEditTime: 2024-09-23 10:49:13
 */
import { extend } from "umi-request";
import type { RequestOptionsInit, ResponseError } from "umi-request";
import type { IBaseResponse } from "@/interfaces/http";
// import loginUtils from "@/utils/login";
import cac from "./cac";
import { message as message2, notification } from "antd";

/** 消息通知，默认时间 */
const duration = 2;
/** 成功返回码 */
const successCode = "000000";

const codeMessage = {
  200: "服务器成功返回请求的数据。",
  201: "新建或修改数据成功。",
  202: "一个请求已经进入后台排队（异步任务）。",
  204: "删除数据成功。",
  400: "发出的请求有错误，服务器没有进行新建或修改数据的操作。",
  401: "用户没有权限（令牌、用户名、密码错误）。",
  403: "用户得到授权，但是访问是被禁止的。",
  404: "发出的请求针对的是不存在的记录，服务器没有进行操作。",
  406: "请求的格式不可得。",
  410: "请求的资源被永久删除，且不会再得到的。",
  422: "当创建一个对象时，发生一个验证错误。",
  500: "服务器发生错误，请检查服务器。",
  502: "网关错误。",
  503: "服务不可用，服务器暂时过载或维护。",
  504: "网关超时。",
};

const header = () => {
  const c_token = cac.common.getCookie("XSRF-TOKEN");
  const { access_token } = cac.token.loadToken();

  if (access_token) {
    localStorage.setItem("access_token", access_token);
  }

  return {
    Authorization: `bearer ${access_token}`,
    "X-XSRF-TOKEN": c_token,
    "X-Requested-With": "XMLHttpRequest",
  };
};

// 请求拦截器
const requestInterceptors = (url: string, options: RequestOptionsInit) => {
  const headers = header();
  // if (url.includes("ver.version")) {
  //   headers["Cache-Control"] = "no-cache";
  // }
  return {
    url,
    options: { ...options, headers, interceptors: true },
  };
};

// 响应拦截器
const responseInterceptors = async (
  response: Response,
  opts: RequestOptionsInit
) => {
  const { status, url } = response;
  if (status === 200) {
    const res: IBaseResponse<any> = await response.json();
    const { code, message } = res;

    if (code === successCode) {
      return {
        ...res,
        successful: true,
      } as any;
    } else {
      if (!opts.skipErrorMessage) {
        // 错误提示大于20个字的需要更长的阅读时间
        message2.warning(message, message.length > 20 ? 5 : 3);
      }
    }
  }
  return response;
};

// 异常处理程序
const errorHandler = async (error: ResponseError) => {
  const { response, request, data } = error;
  if (response && response.status) {
    const { status } = response;
    if (status === 401) {
      notification.error({
        // @ts-ignore
        description: codeMessage[status],
        message: status,
        duration,
      });
      cac.loginUtil.login();
      // 退出登录
      // loginUtils.goLoginPage();
    }
    if (status && status === 403) {
      const msg =
        data && data.msg ? data.msg : data ? data : codeMessage["403"]; // 对403状态码跳转至统一的403页面
      window.location.href = "/403?msg=" + msg;
      // window.location.href = window.location.origin + '/403?msg=功能权限验证失败';
    }
    if (status && status === 500) {
      window.location.href = "/500";
    }
  } else if (!response) {
    if (!request.options.skipErrorMessage) {
      notification.error({
        description: "您的网络发生异常，无法连接服务器",
        message: "网络异常",
      });
    }
  }

  let resError = {};
  try {
    resError = await response.json();
  } catch (e) {
    // console.error(e);
  }

  return {
    ...resError,
    successful: false,
  } as any;
};

// 创建一个新的请求实例
const request = extend({
  header,
  timeout: 1000 * 60 * 30, // 设置超时时间
  errorHandler,
  credentials: "include",
});

request.interceptors.request.use(requestInterceptors);

request.interceptors.response.use(responseInterceptors);

// 导出封装后的请求实例
export default request;
