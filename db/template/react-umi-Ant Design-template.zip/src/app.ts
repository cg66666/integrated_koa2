/*
 * @Description: file content
 * @Author: cg
 * @Date: 2024-05-23 17:00:43
 * @LastEditors: cg
 * @LastEditTime: 2024-10-23 16:14:33
 */
import cac from "@/utils/cac";

export const onRouteChange = ({ location }: any) => {
  console.log("location", location);
};

// 首次进入页面执行,判断cookie
// cac.loginUtil.checkLogin();

function Rem() {
  // 表示1000的设计图,设计图中1rem相当于10PX的默认值
  const whdef = 10 / 1000;
  // 当前窗口的宽度
  const bodyWidth = document.body.clientWidth;

  // 以默认比例值乘以当前窗口宽度,得到该宽度下的相应FONT-SIZE值
  const rem = bodyWidth * whdef;
  document.getElementsByTagName("html")[0].style.fontSize = rem + "px";
}

window.addEventListener("load", Rem);
window.addEventListener("resize", Rem);
