/*
 * @Description: 获取当前最新时间hook
 * @Author: cg
 * @Date: 2024-05-27 00:34:22
 * @LastEditors: cg
 * @LastEditTime: 2024-10-23 16:06:19
 */
import { useEffect, useState, useRef } from "react";

enum switchToWeekEnum {
  "星期日",
  "星期一",
  "星期二",
  "星期三",
  "星期四",
  "星期五",
  "星期六",
}

function padNumber(num: number) {
  return num.toString().padStart(2, "0");
}

const useGetRealTime = () => {
  let timer: number;

  // 用于控制每秒更新频率
  const prevSecond = useRef("00");

  const [timeUnit, setTimeUnit] = useState({
    year: "1970",
    month: "01",
    day: "01",
    dayOfWeek: switchToWeekEnum[3],
    hour: "00",
    minute: "00",
    second: "00",
  });

  function getDateInfoFromTimestamp() {
    // 创建一个新的Date对象，使用传入的时间戳（毫秒）
    const date = new Date(Date.now());
    if (
      padNumber(date.getSeconds()) === "00" ||
      padNumber(date.getSeconds()) !== prevSecond.current
    ) {
      prevSecond.current = padNumber(date.getSeconds());
      setTimeUnit({
        year: date.getFullYear().toString(),
        month: padNumber(date.getMonth() + 1), // 注意：getMonth()返回的是0-11的月份，所以需要+1
        day: padNumber(date.getDate()),
        dayOfWeek: switchToWeekEnum[date.getDay()], // getDay()返回的是0（周日）到6（周六）的数字
        hour: padNumber(date.getHours()),
        minute: padNumber(date.getMinutes()),
        second: padNumber(date.getSeconds()),
      });
    }
    timer = requestAnimationFrame(getDateInfoFromTimestamp);
  }

  useEffect(() => {
    // 延时器，为了解决切换layout导致组件无限刷新问题
    setTimeout(() => {
      requestAnimationFrame(getDateInfoFromTimestamp);
    }, 500);
    return () => {
      cancelAnimationFrame(timer);
    };
  }, []);

  return timeUnit;
};

export default useGetRealTime;
