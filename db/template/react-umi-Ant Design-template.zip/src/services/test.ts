/*
 * @Description: file content
 * @Author: cg
 * @Date: 2024-08-29 14:36:27
 * @LastEditors: cg
 * @LastEditTime: 2024-09-02 18:01:03
 */
import request from "@/utils/request";
import { IBaseResponse } from "@/interfaces/http";

/**
 * 测试接口
 */
export async function test() {
  return request<IBaseResponse<any>>("/cosmo-demo/api/v1/demo", {
    method: "POST",
  });
}

// export async function test2(params: any) {
//   return request<IBaseResponse<any>>("/my-app/test", {
//     method: "POST",
//     data: params,
//   });
// }
