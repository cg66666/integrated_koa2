/*
 * @Description: file content
 * @Author: cg
 * @Date: 2024-09-23 13:33:35
 * @LastEditors: cg
 * @LastEditTime: 2024-09-29 11:13:49
 */
import React, { useEffect, useMemo, useState, createContext } from "react";
import { ConfigProvider, Image, Modal, message, Spin } from "antd";
import {
  useLocation,
  Outlet,
  useParams,
  useRouteData,
  useRouteProps,
  useSelectedRoutes,
  history,
  useOutlet,
  useAppData,
} from "umi";
import s from "./index.scss";

import zh_CN from "antd/es/locale/zh_CN";
// import zhCN from 'antd/locale/zh_CN';
// for date-picker i18n
import "dayjs/locale/zh-cn";

export type pageType = {
  id: string;
  dom: React.ReactElement;
  selected: boolean;
  label: string;
  path: string;
  name: string;
};

const Layout: React.FC = () => {
  const outlet = useOutlet();

  // 获取子路由集合
  // const routes: [] = useSelectedRoutes()[0].route.children;

  // 当前所选路由信息
  // const props = useRouteProps();

  // useEffect(()=>{

  // },[])

  return (
    <div className={s.layoutOutline}>
      <ConfigProvider
        locale={zh_CN}
        // locale={zhCN}
        // input={{ autoComplete: "off" }}
        // renderEmpty={customizeRenderEmpty}
      >
          {outlet}
      </ConfigProvider>
    </div>
  );
};

export default Layout;
