/*
 * @Description: 前置执行js逻辑，用于声明全局变量
 * @Author: cg
 * @Date: 2024-09-24 15:22:14
 * @LastEditors: cg
 * @LastEditTime: 2024-10-23 16:44:38
 */
// import init from "@/assets/index";
// init();
const inIframe = window.location !== window.parent.location;

window.g = {
  inIframe,
  // 产品简称
  projectName: "Test",
  // 产品名称
  projectTitle: "测试",
  // 浏览器图标
  icon: "/rss/project/icon/dqm.ico",
  // 导航栏图标
  logo: "/rss/project/icon/dqm.png",
  // 关于窗图标
  logo128: "/dqm/change/img/about.png",
  // cac 使用的url
  cacUrl: "/cag",
};

document.title = window.g.projectName;
