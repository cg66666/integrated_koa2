/*
 * @Description: file content
 * @Author: cg
 * @Date: 2024-08-27 17:39:11
 * @LastEditors: cg
 * @LastEditTime: 2024-10-30 15:27:07
 */
import React, { useEffect, useState } from "react";
import { useSelectedRoutes, history, useRouteProps } from "umi";
import { Empty } from "antd";
import s from "./index.scss";

const Test: React.FC<any> = () => {
  console.log(window.g);

  // 当前所选路由信息
  // const props = useRouteProps();

  // const [iframeUrl, setIframeUrl] = useState("");

  // useEffect(() => {
  //   if (props.path != "/" && childPath) {
  //     // 根据环境替换
  //     if (process.env.NODE_ENV === "development") {
  //       setIframeUrl("http://localhost:8001" + props.path + childPath);
  //     } else if (process.env.NODE_ENV === "production") {
  //       setIframeUrl(window.location.origin + props.path + childPath);
  //     }
  //   }
  // }, [props.id, childPath]);

  return <div>react-umi-ant-template</div>;
};

export default Test;
