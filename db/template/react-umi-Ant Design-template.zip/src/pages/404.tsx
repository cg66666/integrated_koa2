/*
 * @Author: cg
 * @Date: 2022-07-05 09:31:13
 * @Description: 404页面
 */
import { Button, Result } from "antd";
import React from "react";
import { history } from "umi";

const NoFoundPage: React.FC = () => {
  // 非研发环境下跳转到统一404页面
  if (process.env.NODE_ENV !== "development")
    location.href = window.location.origin + "/404";

  return (
    <Result
      status="404"
      title="404"
      subTitle="对不起, 访问的页面不存在."
      extra={
        <Button type="primary" onClick={() => history.push("/")}>
          返回首页
        </Button>
      }
    />
  );
};

export default NoFoundPage;
